How to run the server:

1. Install dependencies:
	npm install express express-session body-parser cors mysql2 nbbcjs

2. Run database.sql via MySQL or a compatible SQL system

3. Go to line 25 of server.js and modify it to use your SQL database credentials! It will not be able to communicate with the database otherwise.

Run server:
	node server.js

Go to http//localhost:3000/ to see the index page. If the database was set up properly, you will be able to create an account, publish posts, and comment on posts. You will also be able to edit and delete your own posts and comments. Admin accounts may edit or delete anyone's posts. Currently there is no means to make an account into an Admin via the website; you will need to modify the database directly if you wish to test this feature.

The website should be protected against SQL and JS injection. Users can format their posts using BBCode if so desired.